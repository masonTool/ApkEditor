package com.mapeiyu

import org.gradle.api.Plugin
import org.gradle.api.Project
import org.gradle.api.file.FileCollection
import org.gradle.api.file.FileTree

import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ExcluderPlugin implements Plugin<Project> {

    @Override
    void apply(Project project) {

        def excluder = project.container(Rule)

        project.extensions.excluder = excluder

        project.task('hello') {
            doLast {
                println "Hello from the GreetingPlugin"
            }
        }

        project.afterEvaluate {
            project.android.applicationVariants.all { variant ->
                println "<<$variant.name"

                if (variant.name == 'release') {
                    return
                }

                def excludeList = []
                def includeList = []

                //
                // find all flavors and build type of this variont
                //
                def flavors = (variant.productFlavors.name).collect()
                flavors << variant.buildType.name

                //
                // detect all excluding rules for this variant
                //
                excluder.matching { rule ->
                    flavors.any { flavName ->
                        flavName.matches(rule.name)
                    }
                }.all { rule ->
                    excludeList.addAll(rule.excludeList)
                    includeList.addAll(rule.includeList)
                }

                variant.outputs.each { output ->
//                    output.packageApplication.doFirst { pkgApp ->
//                        boolean dealWithIt = excludeList.size > 0 || includeList.size > 0
//
//                        if (dealWithIt) {
//
//                            File res = pkgApp.resourceFile
//                            ZipUtil.updateZip(project, pkgApp.resourceFile, '**/drawable-xxxhdpi-v4/**')
//
//                            println "<<<<<<<<<<<<<<<<<<<<<<"
//
//                            FileTree rr = project.fileTree(pkgApp.assets)
//                            includeList?.each {
//                                rr.include it
//                            }
//
//                            excludeList?.each {
//                                println "bbbbbb $it"
//                                rr.exclude it
//                            }
//
//
//                            //
//                            // remove all excluded so files
//                            //
//                            println "11111111"
//                            rr.each {
//                                println it
//                            }
//
//                            println "22222222"
//                            project.fileTree(pkgApp.assets).each {
//                                println it
//                            }
//
//                            println "33333333"
//                            FileCollection ff = project.fileTree(pkgApp.assets).minus(rr)
//
//                            ff.each {
//                                println "44444444"
//                                println it
//                                it.delete()
//                            }
//
//
//                            pkgApp.jniFolders.each { dir ->
//                                //
//                                // find all so files needed by this output
//                                //
//                                FileTree reserve = project.fileTree(dir) { fileTree ->
//                                    includeList?.each {
//                                        fileTree.include it
//                                    }
//
//                                    excludeList?.each {
//                                        println "eeeee $it"
//                                        fileTree.exclude it
//                                    }
//                                }
//
//                                println "555555"
//                                project.fileTree(dir).each {
//                                    println it
//                                }
//
//
//                                println "66666666666"
//
//                                reserve.each {
//                                    println it
//                                }
//
//
//                                //
//                                // remove all excluded so files
//                                //
//                                FileCollection remove = project.fileTree(dir).minus(reserve)
//
//                                println "77777777"
//
//                                remove.each {
//                                    println it
//                                    it.delete()
//                                }
//
//
//                            }
//
//                            println "88888"
////                            project.fileTree(pkgApp.resourceFile.parent + "/merged/debug").each {
////                                println it
////                                it.delete()
////                            }
////                            println "999999"
//                        }
//
//                    }


                    output.packageApplication.doLast { pkgApp ->

//                        println "start ppppppppppppppppp"
//                        println "jni $pkgApp.jniFolders"
                        println "pkgApp.resourceFile $pkgApp.resourceFile"
                        println "pkgApp.dexFolders $pkgApp.dexFolders"
                        println "pkgApp.javaResourceFiles $pkgApp.javaResourceFiles"
//                        println "pkgApp.assets $pkgApp.assets"
                        println "$pkgApp.outputFile === ${pkgApp.outputFile.exists()}"
//                        println "pkgApp.incrementalFolder $pkgApp.incrementalFolder"
//                        println "end ppppppppppppppppp"
                        println("eeeeeeeeeeeeeeeeeeee")
                        ZipUtil.updateZip(project, pkgApp.outputFile, excludeList as String[])

                    }
                }

                println ">>"
            }

        }
    }
}
